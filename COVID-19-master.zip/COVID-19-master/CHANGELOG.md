# Changelog

Tutte le modifiche ai dataset e nuove funzionalità e informazioni sono documentate in questo file

## 2020-03-08

- Modificato dataset andamento riportando i totali dei dati delle Regioni
- Rimossa directory shape-aree-contenimento e creata aree con shp e geojson




